# tutorial.tex

This is a copy of the tutorial.tex file that used to be part of the csquotes package. 

I stumbled across a reference to this file from a thread on [latex community][ltxcom] and was unable to find the file. I posted a [question][texsxq] on tex.sx and someone on tex.sx was kind enough to find it for me. 

I have placed it here for anyone else that may be interested but be sure to check the official [csquotes documentation.][csquotes]


[csquotes]: http://www.tug.org/texlive/Contents/live/texmf-dist/doc/latex/csquotes/csquotes.pdf
[texsxq]: http://tex.stackexchange.com/q/43909/7490
[ltxcom]: http://www.latex-community.org/forum/viewtopic.php?f=44&t=5444
 

dfc

